# Pesquisa Relampago

- **Funções em SQL**

As funções em SQL são comandos usados para manipular textos, realizar calculos e organizar informações no banco de dados.

**1. Funções Matemáticas**

São usados para realizar calculos matematicos com valores numericos, como, soma, divisão, arredondamento e obtenção de valores absolutos.

**Principais funções:** 

| Função | O que faz | Exemplo |
| --- | --- | --- |
| `ABS()` | Retorna o valor absoluto de um número. | `ABS(-10)` = 10 |
| `ROUND()` | Arredonda um número. | `ROUND(5.678, 2)` = 5.68 |
| `CEIL()` | Arredonda para cima. | `CEIL(4.2)` = 5 |
| `FLOOR()` | Arredonda para baixo. | `FLOOR(4.9)` = 4 |
| `SQRT()` | Calcula a raiz quadrada. | `SQRT(25)` = 5 |
| `MOD()` | Retorna o resto de uma divisão. | `MOD(10, 3)` = 1 |

**Exemplo prático:**

SELECT ROUND(15.678, 2);

Resultado: `15.68`

Nesse exemplo, o SQL arredonda o número para duas casas decimais.

**2. Funções de String (Texto)**

São usadas para manipular informações textuais, permitindo alteras letras, juntar palavras, contar caracteres e localizar parte de um texto.]

**Principais funções:**

| Função | O que faz | Exemplo |
| --- | --- | --- |
| `UPPER()` | Transforma o texto em letras maiúsculas. | `UPPER('ana')` = ANA |
| `LOWER()` | Transforma o texto em letras minúsculas. | `LOWER('JOÃO')` = joão |
| `LENGTH()` | Retorna o tamanho do texto em bytes. | `LENGTH('Casa')` = 4 |
| `CONCAT()` | Junta dois ou mais textos. | `CONCAT('Olá', ' Ana')` = Olá Ana |
| `SUBSTRING()` | Retira uma parte do texto. | `SUBSTRING('Computador', 1, 4)` = Comp |
| `TRIM()` | Remove espaços do início e do final. | `TRIM(' Ana ')` = Ana |
|  |  |  |
|  |  |  |

**Exemplo prático:**

SELECT UPPER('banco de dados');

Resultado: `BANCO DE DADOS`

Nesse exemplo, o SQL transforma todas as letras do texto em maiúsculas.

**3. Funções de Data e Hora**

São usadas para trabalhar com datas e horários, permitindo consultar e verificar data e horário atual e calcular diferença entre datas.

**Principais funções:**

| Função | O que faz | Exemplo |
| --- | --- | --- |
| `NOW()` | Retorna a data e a hora atuais. | Data e hora atual |
| `CURDATE()` | Retorna a data atual. | 2026-11-24 |
| `CURTIME()` | Retorna o horário atual. | 07:45:00 |
| `YEAR()` | Retorna o ano de uma data. | `YEAR('2026-11-24')` = 2026 |
| `MONTH()` | Retorna o mês de uma data. | `MONTH('2026-11-24')` = 11 |
| `DAY()` | Retorna o dia de uma data. | `DAY('2026-11-24')` = 24 |
| `DATEDIFF()` | Calcula a diferença entre duas datas em dias. | `DATEDIFF('2026-11-24', '2026-11-20')` = 4 |
| `DATE_ADD()` | Adiciona um período a uma data. | Adiciona 5 dias |

**Exemplo prático:**

SELECT NOW();

Resultado: retorna a data e o horário atuais.

**4. Subconsultas (Subqueries)**

São consultas realizadas dentro de outra consulta SQL.  São usadas para buscar informações e utilizá-las para filtrar ou comparar dados.

**Exemplo:**

SELECT nome
FROM funcionarios
WHERE salario > (
SELECT AVG(salario)
FROM funcionarios
);

Nesse exemplo, a subconsulta calcula a média salarial e a consulta principal mostra os funcionários que ganham acima dela.
****

- **Conclusão:**

As funções e subconsultas em SQL são ferramentas importantes para o gerenciamento de bancos de dados. Elas permitem realizar cálculos matemáticos, manipular textos, trabalhar com datas e horários e buscar informações específicas. Dessa forma, tornam as consultas mais práticas, rápidas e organizadas.